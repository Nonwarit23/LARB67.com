const c = document.getElementById("game");
const x = c.getContext("2d");
const scoreEl = document.getElementById("score");
const timeEl = document.getElementById("time");
const diffDisplay = document.getElementById("diff-display");
const diffModal = document.getElementById("difficulty-modal");
const countdownOverlay = document.getElementById("countdown-overlay");
const countdownText = document.getElementById("countdown-text");

let running = false;
let score = 0;
let time = 30;
let last = 0;
let fruits = [];
let particles = [];
let slashes = [];
let mouse = { x: 0, y: 0 };
let currentDiff = 'normal';
let spawnTimer = 0;
let spawnInterval = 1.2;

const DIFF_SETTINGS = {
    baby: { label: 'Baby', spawnInt: 1.5, speedMult: 0.75, maxFruits: 2 },
    normal: { label: 'Normal', spawnInt: 1.0, speedMult: 1.0, maxFruits: 3 },
    hard: { label: 'Hard', spawnInt: 0.7, speedMult: 1.3, maxFruits: 4 },
    hardcore: { label: 'Hardcore', spawnInt: 0.45, speedMult: 1.7, maxFruits: 6 }
};

function selectDifficulty(diff) {
    currentDiff = diff;
    diffModal.classList.add('hidden');
    startCountdown();
}

function startCountdown() {
    countdownOverlay.classList.remove('hidden');
    let count = 3;
    countdownText.textContent = count;
    
    let timer = setInterval(() => {
        count--;
        if (count > 0) {
            countdownText.textContent = count;
        } else if (count === 0) {
            countdownText.textContent = "START!";
        } else {
            clearInterval(timer);
            countdownOverlay.classList.add('hidden');
            startGameplay();
        }
    }, 1000);
}

function spawn() {
    const config = DIFF_SETTINGS[currentDiff];
    const fromTop = Math.random() < 0.5; // สุ่มหล่นจากบน หรือพุ่งขึ้นจากล่าง
    
    const emojiList = ["🍉", "🍎", "🍊", "🍓", "🍍", "🍌", "🍇", "🥝"];
    const radius = 28 + Math.random() * 12;
    const posX = 80 + Math.random() * (c.width - 160);
    
    let posY, vy, vx;
    
    if (fromTop) {
        posY = -radius - 10;
        vy = (180 + Math.random() * 120) * config.speedMult; // ความเร็วตก
        vx = (Math.random() - 0.5) * 100;
    } else {
        posY = c.height + radius + 10;
        vy = -(520 + Math.random() * 180) * config.speedMult; // แรงส่งขึ้นบน
        vx = (Math.random() - 0.5) * 160;
    }

    fruits.push({
        x: posX,
        y: posY,
        vx: vx,
        vy: vy,
        gravity: fromTop ? 180 : 580,
        r: radius,
        emoji: emojiList[Math.floor(Math.random() * emojiList.length)],
        fromTop: fromTop
    });
}

function burst(px, py) {
    for (let i = 0; i < 28; i++) {
        let a = Math.random() * Math.PI * 2;
        let s = 100 + Math.random() * 260;
        particles.push({
            x: px, y: py,
            vx: Math.cos(a) * s,
            vy: Math.sin(a) * s,
            life: 0.45 + Math.random() * 0.4,
            max: 0.85,
            size: 3 + Math.random() * 6
        });
    }
}

function slash(px, py) {
    slashes.push({ x1: mouse.x, y1: mouse.y, x2: px, y2: py, life: 0.14, max: 0.14 });
    burst(px, py);
}

function draw() {
    x.fillStyle = "#111b2e";
    x.fillRect(0, 0, c.width, c.height);
    let g = x.createLinearGradient(0, 0, 0, c.height);
    g.addColorStop(0, "#101e38");
    g.addColorStop(1, "#24365a");
    x.fillStyle = g;
    x.fillRect(0, 0, c.width, c.height);
    
    x.fillStyle = "#fff";
    for (let i = 0; i < 60; i++) {
        x.globalAlpha = 0.3 + (i % 3) * 0.15;
        x.fillRect((i * 151) % c.width, (i * 73) % c.height, 2, 2);
    }
    x.globalAlpha = 1;

    // วาดผลไม้
    fruits.forEach(f => {
        x.save();
        x.shadowColor = "#fff";
        x.shadowBlur = 18;
        x.font = f.r * 2.1 + "px 'Segoe UI Emoji','Apple Color Emoji',sans-serif";
        x.textAlign = "center";
        x.textBaseline = "middle";
        x.fillText(f.emoji, f.x, f.y);
        x.restore();
    });

    // วาดเอฟเฟกต์ระเบิด
    particles.forEach(q => {
        x.globalAlpha = Math.max(0, q.life / q.max);
        x.fillStyle = "#ffcf4a";
        x.shadowColor = "#ff8b2e";
        x.shadowBlur = 12;
        x.beginPath();
        x.arc(q.x, q.y, q.size, 0, Math.PI * 2);
        x.fill();
    });

    // วาดรอยฟัน
    slashes.forEach(s => {
        x.globalAlpha = s.life / s.max;
        x.strokeStyle = "#fff";
        x.shadowColor = "#6ee7ff";
        x.shadowBlur = 18;
        x.lineWidth = 9;
        x.lineCap = "round";
        x.beginPath();
        x.moveTo(s.x1, s.y1);
        x.lineTo(s.x2, s.y2);
        x.stroke();
        
        x.strokeStyle = "#8be9ff";
        x.lineWidth = 3;
        x.beginPath();
        x.moveTo(s.x1, s.y1);
        x.lineTo(s.x2, s.y2);
        x.stroke();
    });
    x.globalAlpha = 1;
}

function loop(t) {
    if (!running) return;
    let dt = Math.min((t - last) / 1000, 0.03);
    last = t;

    time -= dt;
    if (time <= 0) {
        time = 0;
        running = false;
        diffDisplay.textContent = DIFF_SETTINGS[currentDiff].label + " (จบเกม)";
    }
    timeEl.textContent = Math.ceil(time);

    // เกิดผลไม้ตามจังหวะ
    const config = DIFF_SETTINGS[currentDiff];
    spawnTimer += dt;
    if (spawnTimer >= config.spawnInt && fruits.length < config.maxFruits) {
        spawnTimer = 0;
        spawn();
    }

    // อัปเดตตำแหน่งผลไม้
    fruits.forEach(f => {
        f.x += f.vx * dt;
        f.y += f.vy * dt;
        f.vy += f.gravity * dt;
    });

    // ลบผลไม้ที่ตกขอบ
    fruits = fruits.filter(f => f.y < c.height + 60 && f.y > -100);

    // อัปเดตพาร์ทิเคิลและฟัน
    particles.forEach(q => {
        q.x += q.vx * dt;
        q.y += q.vy * dt;
        q.vy += 280 * dt;
        q.life -= dt;
    });
    particles = particles.filter(q => q.life > 0);

    slashes.forEach(s => s.life -= dt);
    slashes = slashes.filter(s => s.life > 0);

    draw();
    if (running) requestAnimationFrame(loop);
}

function checkSlice(mx, my) {
    if (!running) return;
    for (let i = fruits.length - 1; i >= 0; i--) {
        let f = fruits[i];
        if (Math.hypot(mx - f.x, my - f.y) < f.r + 18) {
            score += 10;
            scoreEl.textContent = score;
            slash(f.x, f.y);
            fruits.splice(i, 1);
            break;
        }
    }
}

c.addEventListener("pointermove", e => {
    let r = c.getBoundingClientRect();
    mouse.x = (e.clientX - r.left) * c.width / r.width;
    mouse.y = (e.clientY - r.top) * c.height / r.height;
    if (e.buttons === 1) checkSlice(mouse.x, mouse.y);
});

c.addEventListener("pointerdown", e => {
    let r = c.getBoundingClientRect();
    let mx = (e.clientX - r.left) * c.width / r.width;
    let my = (e.clientY - r.top) * c.height / r.height;
    checkSlice(mx, my);
});

document.getElementById("start").onclick = () => {
    diffModal.classList.remove('hidden');
};

function startGameplay() {
    score = 0;
    time = 30;
    fruits = [];
    particles = [];
    slashes = [];
    spawnTimer = 0;
    scoreEl.textContent = 0;
    timeEl.textContent = 30;
    diffDisplay.textContent = DIFF_SETTINGS[currentDiff].label;
    
    spawn();
    running = true;
    last = performance.now();
    draw();
    requestAnimationFrame(loop);
}

function goHome() {
    window.parent.postMessage("close-game", "*");
}

draw();